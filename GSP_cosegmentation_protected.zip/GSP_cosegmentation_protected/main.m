db='./data/';
vlf;
cosegmentation(db);
        
 