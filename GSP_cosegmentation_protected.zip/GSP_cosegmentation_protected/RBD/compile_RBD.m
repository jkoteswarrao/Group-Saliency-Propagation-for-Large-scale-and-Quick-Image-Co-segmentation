cd ./Funcs/SlIC/
mex SLIC_mex.cpp SLIC.cpp
cd ../../